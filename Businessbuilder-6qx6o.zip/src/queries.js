import { HttpError } from 'wasp/server'

export const getWorkflowAnalytics = async ({ workflowId }, context) => {
  if (!context.user) { throw new HttpError(401); }

  const workflow = await context.entities.Workflow.findUnique({
    where: { id: workflowId },
    include: {
      owner: true,
      // Add other relations if needed for detailed analytics
    }
  });

  if (!workflow || workflow.ownerId !== context.user.id) {
    throw new HttpError(404, 'Workflow not found or access denied.');
  }

  // Replace the following line with actual analytics computation logic
  const analyticsData = {
    performance: 'Good',
    bottlenecks: 'None'
  };

  return analyticsData;
}

export const getChatHistory = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Chat.findMany({
    where: {
      userId: context.user.id
    },
    orderBy: {
      id: 'asc'
    }
  });
}

export const suggestPartnerMatch = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const userWorkflows = await context.entities.Workflow.findMany({
    where: { ownerId: context.user.id },
    select: { title: true }
  });

  if (!userWorkflows.length) throw new HttpError(404, 'No workflows found for the user.');

  // Dummy logic for partner suggestion based on workflow titles
  const potentialPartners = await context.entities.User.findMany({
    where: {
      workflows: {
        some: {
          title: { in: userWorkflows.map(workflow => workflow.title) }
        }
      }
    },
    select: {
      id: true,
      workflows: { select: { title: true } }
    }
  });

  return potentialPartners.filter(partner => partner.id !== context.user.id);
}
