import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { suggestPartnerMatch } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const PartnerMatchPage = () => {
  const { data: partners, isLoading, error } = useQuery(suggestPartnerMatch);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error.message;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Potential Partner Matches</h1>
      <div className='space-y-4'>
        {partners.map((partner) => (
          <div key={partner.id} className='p-4 bg-gray-100 rounded-lg shadow'>
            <h2 className='text-xl font-semibold'>{partner.name}</h2>
            <ul className='list-disc pl-5 mt-2'>
              {partner.workflows.map((workflow, index) => (
                <li key={index}>{workflow.title}</li>
              ))}
            </ul>
            <Link
              to={`/partners/${partner.id}`}
              className='text-blue-500 hover:underline mt-2 block'
            >
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PartnerMatchPage;
