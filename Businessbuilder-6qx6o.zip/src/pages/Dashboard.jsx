import React from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getWorkflowAnalytics, getChatHistory, createCampaign, updateWorkflow } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: workflows, isLoading: workflowsLoading, error: workflowsError } = useQuery(getWorkflowAnalytics, { workflowId: 1 }); // Example workflowId
  const { data: chats, isLoading: chatsLoading, error: chatsError } = useQuery(getChatHistory);
  const createCampaignFn = useAction(createCampaign);
  const updateWorkflowFn = useAction(updateWorkflow);

  if (workflowsLoading || chatsLoading) return 'Loading...';
  if (workflowsError) return 'Error loading workflows: ' + workflowsError.message;
  if (chatsError) return 'Error loading chats: ' + chatsError.message;

  const handleCreateCampaign = () => {
    createCampaignFn({ name: 'New Campaign' });
  };

  const handleUpdateWorkflow = () => {
    updateWorkflowFn({ id: 1, data: { title: 'Updated Workflow' } }); // Example data
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Dashboard</h1>
      <div className='mb-4'>
        <button onClick={handleCreateCampaign} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>
          Create Campaign
        </button>
        <button onClick={handleUpdateWorkflow} className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2'>
          Update Workflow
        </button>
      </div>
      <div className='bg-gray-100 p-4 rounded mb-4'>
        <h2 className='text-xl font-semibold mb-2'>Workflows</h2>
        {workflows && <div>Performance: {workflows.performance}</div>}
        {workflows && <div>Bottlenecks: {workflows.bottlenecks}</div>}
      </div>
      <div className='bg-gray-100 p-4 rounded'>
        <h2 className='text-xl font-semibold mb-2'>Chat History</h2>
        {chats.map(chat => (
          <div key={chat.id} className='mb-2'>
            {chat.content}
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardPage;
