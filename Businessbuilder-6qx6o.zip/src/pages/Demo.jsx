import React from 'react';
import { useAction } from 'wasp/client/operations';
import { generateProposal } from 'wasp/client/operations';

const DemoPage = () => {
  const generateProposalFn = useAction(generateProposal);

  const handleGenerateProposal = async () => {
    try {
      const proposal = await generateProposalFn({ workflowId: 1 }); // Example workflowId
      console.log('Generated Proposal:', proposal);
    } catch (error) {
      console.error('Error generating proposal:', error);
    }
  };

  return (
    <div className="p-8 bg-white shadow-md rounded-lg">
      <h1 className="text-2xl font-bold mb-4">Live Demo</h1>
      <p className="mb-4">Experience the workflow tailored to your role.</p>
      <button
        onClick={handleGenerateProposal}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      >
        Generate Proposal
      </button>
    </div>
  );
};

export default DemoPage;
